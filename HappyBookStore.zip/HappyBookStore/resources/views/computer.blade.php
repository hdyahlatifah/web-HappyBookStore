@extends('navbar')
@section('title', 'Computer Category')
@section('content')
    <div class="col-sm-8">
        <h3>Computer</h3>
        <table class="table">
            <thead class="thead-dark">
            <tr>
                <th>Title</th>
                <th>Author</th>
            </tr>
            </thead>
            <body>
            <tr>
                <td>
                    <button class="btn btn-link">Computer</button>
                </td>
                <td>Someone Who Cares</td>
            </tr>
            </body>
        </table>
    </div>
@endsection
