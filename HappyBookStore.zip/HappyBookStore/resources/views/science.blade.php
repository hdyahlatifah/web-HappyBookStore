@extends('navbar')
@section('title', 'Science Category')
@section('content')
    <div class="col-sm-8">
        <h3>Science</h3>
        <table class="table">
            <thead class="thead-dark">
            <tr>
                <th>Title</th>
                <th>Author</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <td>
                    <button class="btn btn-link">Science</button>
                </td>
                <td>Someone Who Cares</td>
            </tr>
            </tbody>
        </table>
    </div>
@endsection
