@extends('navbar')
@section('title', 'Book Detail')
@section('content')
    <div class="col-sm-8">
        <h3>Book Detail</h3>
        <table class="table">
            <thead class="thead-dark">
            <tr>
                <th>Title</th>
                <th>Author</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <button class="btn btn-link">Fiction</button>
                <td>Someone Who Cares</td>
            </tr>
            </tbody>
        </table>
    </div>
@endsection
