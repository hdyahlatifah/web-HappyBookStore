@extends('navbar')
@section('title', 'Home')
@section('content')
            <div class="col-sm-8">
                <h3>Book List</h3>
                <table class="table">
                    <thead class="thead-dark">
                    <tr>
                        <th>Title</th>
                        <th>Author</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($book as $b)
                    <tr>
                        <td>
                            <button class="btn btn-link">{{$b->title}}</button>
                        </td>
                        <td>Someone Who Cares</td>
                    </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>

@endsection

