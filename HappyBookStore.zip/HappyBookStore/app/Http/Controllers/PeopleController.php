<?php

namespace App\Http\Controllers;

use App\Models\Book;
use App\Models\Categories;
use Illuminate\Http\Request;

class PeopleController extends Controller
{
    public function showBookListpage(){
        $book = Book::all();

        return view('home', compact('book'));
    }

    public function showKontakpage(){
        return view('contact');
    }

    public function showFictionkpage(){
        return view('fiction');
    }

    public function showSciencepage(){
        return view('science');
    }

    public function showComputerpage(){
        return view('computer');
    }

}
