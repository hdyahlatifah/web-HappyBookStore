<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('content'); ?>
            <div class="col-sm-8">
                <h3>Book List</h3>
                <table class="table">
                    <thead class="thead-dark">
                    <tr>
                        <th>Title</th>
                        <th>Author</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $book; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <button class="btn btn-link"><?php echo e($b->title); ?></button>
                        </td>
                        <td>Someone Who Cares</td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\semester 5\uts\webprog\HappyBookStore\HappyBookStore\resources\views/home.blade.php ENDPATH**/ ?>