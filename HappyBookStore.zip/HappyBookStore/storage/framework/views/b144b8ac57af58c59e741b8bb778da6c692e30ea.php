<?php $__env->startSection('title', 'Computer Category'); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-sm-8">
        <h3>Computer</h3>
        <table class="table">
            <thead class="thead-dark">
            <tr>
                <th>Title</th>
                <th>Author</th>
            </tr>
            </thead>
            <body>
            <tr>
                <td>
                    <button class="btn btn-link">Computer</button>
                </td>
                <td>Someone Who Cares</td>
            </tr>
            </body>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\semester 5\uts\webprog\HappyBookStore\HappyBookStore\resources\views/computer.blade.php ENDPATH**/ ?>