<!DOCTYPE html>
<html lang="en">
<head>
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>
        .footer {
            position: fixed;
            left: 0;
            bottom: 0;
            width: 100%;
            height: 50px;
            background-color: #2d3748;
            color: #a0aec0;
            text-align: center;
        }

    </style>

</head>
<body>

<div class="jumbotron text-center" style="margin-bottom:0">
    <h1>HAPPY BOOK STORE</h1>
</div>

<nav class="navbar navbar-expand-sm bg-light justify-content-center">
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" href="/home">Home</a>
        </li>
        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Category
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="/fiction">Fiction</a>
                <a class="dropdown-item" href="/science">Science</a>
                <a class="dropdown-item" href="/computer">Computer</a>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="/contact">Contact</a>
        </li>
    </ul>
</nav>


<div class="container" style="margin-top:30px">
    <div class="row">
        <?php echo $__env->yieldContent('content'); ?>
        <div class="col-sm-4">
            <ul class="nav nav-pills flex-column">
                <li class="nav-item">
                    <a class="nav-link active" href="#">Category</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/fiction">Fiction</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/science">Science</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/computer">Computer</a>
                </li>
            </ul>
            <hr class="d-sm-none">
        </div>

    </div>
</div>

<div class="footer">
    <div class="container text-center">
        <small>©Happy Book Store 2021</small>
    </div>
</div>
</body>
</html>
<?php /**PATH D:\semester 5\uts\webprog\HappyBookStore\HappyBookStore\resources\views/navbar.blade.php ENDPATH**/ ?>