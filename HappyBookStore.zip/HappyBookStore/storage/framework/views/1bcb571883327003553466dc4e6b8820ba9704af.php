<?php $__env->startSection('title', 'Contact'); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-sm-8">
        <h3>Contact</h3>
        <h2>Store address :</h2>
        <p>Jalan Pembangunan Baru Raya,
            Kompleks Pertokoan Emerald Blok III/12
            Bintaro, Tangerang Selatan Indonesia
        </p>
        <br>
        <h2>Open Daily:</h2>
        <p>08.00 - 20.00</p>
        <br>
        <h2>Contact : </h2>
        <p>Phone : 021-009686078755</p>
        <p>Email: happybookstore@happy.com</p>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\semester 5\uts\webprog\HappyBookStore\HappyBookStore\resources\views/contact.blade.php ENDPATH**/ ?>