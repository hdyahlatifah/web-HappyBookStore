<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PeopleController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('contact');
});

Route::get('/home', [\App\Http\Controllers\PeopleController::class, 'showBookListpage']);
Route::get('/contact', [\App\Http\Controllers\PeopleController::class, 'showKontakpage']);
Route::get('/fiction', [\App\Http\Controllers\PeopleController::class, 'showFictionkpage']);
Route::get('/science', [\App\Http\Controllers\PeopleController::class, 'showSciencepage']);
Route::get('/computer', [\App\Http\Controllers\PeopleController::class, 'showComputerpage']);

