<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class BookSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('books')->insert([
            'categories_id' => 1,
            'title' => 'Le Mariage: The Promise of Forever'
        ]);

        DB::table('books')->insert([
            'categories_id' => 1,
            'title' => 'LiT: Catatan Tentang Hujan'
        ]);

        DB::table('books')->insert([
            'categories_id' => 1,
            'title' => 'Ketika Cinta Jadi Nyata'
        ]);
        DB::table('books')->insert([
            'categories_id' => 2,
            'title' => 'Science Experiments You Can Eat'
        ]);
        DB::table('books')->insert([
            'categories_id' => 2,
            'title' => 'Why Science Does Not Disprove God'
        ]);
        DB::table('books')->insert([
            'categories_id' => 2,
            'title' => 'LThe Science of Liberty'
        ]);
        DB::table('books')->insert([
            'categories_id' => 2,
            'title' => 'The Science of Superstition'
        ]);
        DB::table('books')->insert([
            'categories_id' => 3,
            'title' => 'Mengenal Komputer For Beginners'
        ]);
        DB::table('books')->insert([
            'categories_id' => 3,
            'title' => 'Program Komputer Untuk Analisa Ekonomi'
        ]);
        DB::table('books')->insert([
            'categories_id' => 1,
            'title' => 'Le Mariage: The Promise of Forever'
        ]);
    }
}
