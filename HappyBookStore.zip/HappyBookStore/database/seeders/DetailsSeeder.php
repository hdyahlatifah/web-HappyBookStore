<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DetailsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('details')->insert([
            'books_id' => 1,
            'author' => 'Tiara.R',
            'publisher' => 'Elexmedia Komputindo',
            'year' => '2001',
            'description' => 'Setelah kehilangan anak dan pernikahannya, Renae Adiana tidak lagi memercayai cinta dan adanya akhir yang bahagia. Dengan kekurangan terbesar yang dimiliki Renae, tidak akan ada laki-laki yang menginginkan Renae sebagai istrinya. Oleh karena itu, Renae mencurahkan waktunya untuk menyembuhkan trauma dan mengembangkan La Papeterie—toko luxury stationery yang dirintisnya. Hal terakhir yang dibutuhkan Renae adalah kehadiran Halmar Karlsson—co-founder dan CEO Ink Live—yang membuat Renae ingin merasakan dicintai dan mencintai lagi. Halmar tidak pernah takut bekerja keras demi mewujudkan keinginannya. Sebuah perusahaan bioteknologi yang mendunia dan berbagai macam penghargaan yang diterimanya adalah bukti kegigihannya. Satu atau dua kalimat penolakan dari Renae tidak akan membuat langkah Halmar surut. Sebelum kembali ke Swedia, Halmar bertekad harus bisa memenangkan hati Renae, wanita yang menghuni pikirannya sejak pertemuan pertama. Hanya satu yang diminta Halmar dari Renae. Kesempatan untuk membuktikan janjinya. Akankah Renae berani memberikan? Atau Halmar terpaksa mundur dan menerima kekalahan?',
        ]);

        DB::table('details')->insert([
            'books_id' => 2,
            'author' => 'Anindya Frista',
            'publisher' => 'Agro Media',
            'year' => '2019',
            'description' => 'Dalam rinai kisah kita terlukiskan Kau yang tak lelah berjuang, kepada kerasku yang kaululuhkan Sekarang biarkan aku menjadi laut yang menyimpan dalam semua rahasia kita Seperti ombak di tengah samudra, biar aku yang berkelana jauh Lalu pulang, kembali ke pelukmu, sang tepian Fajar dan Senja saling jatuh cinta. Seharusnya sesederhana itu buat jadian. Tapi Senja tidak tahu rahasia-rahasia yang disimpan Fajar, sama seperti tidak tahunya Fajar pada isi hati Senja, apakah benar-benar untuknya, atau untuk cowok lain? Ini rumit. Tapi … bukan cinta namanya kalau tidak membingungkan. Iya, kan?',
            ]);

        DB::table('details')->insert([
            'books_id' => 3,
            'author' => 'Annisa Ihsani',
            'publisher' => 'Agro Media',
            'year' => '2021',
            'description' => 'Amanda punya satu masalah kecil: dia yakin bahwa dia tidak sepandai kesan yang ditampilkannya. Dia meyakini rapornya selalu berisi nilai A hanya karena keberuntungan berpihak padanya. Tampaknya para guru hanya menanyakan pertanyaan yang kebetulan dia ketahui jawabannya. Namun, tidak mungkin ada orang yang bisa beruntung setiap saat, kan? Orang lain mungkin berpikir itu bukan masalah besar. Apalagi mengingat hidupnya diisi dengan berbagai kesempurnaan. Namun, pada akhirnya dia harus mengikuti serangkaian perjanjian psikoterapi. Ketika pulang dengan resep antidepresan, Amanda tahu masalahnya lebih pelik daripada yang siap diakuinya. Di tengah kerumitan dengan pacar, keluarga, dan sekolahnya, Amanda harus menerima bahwa dia tidak bisa mendapatkan nilai A untuk segalanya.'
            ]);
        DB::table('details')->insert([
            'books_id' => 4,
            'author' => 'Erin Watt',
            'publisher' => 'Gramedia Pustaka Utama (GPU)',
            'year' => '2021',
            'description' => 'Karier Oakley Ford sang bintang pop sedang mandek. Sudah dua tahun ia tidak merilis album dan follower di media sosialnya berkurang. Ia tidak ingin kariernya berakhir bahkan sebelum ulang tahunnya yang kedua puluh, tapi mengikuti saran pihak manajemen untuk mencari pacar bohongan demi strategi promosi rasanya agak kelewatan. Ya, kan? Tetapi mungkin demi citra diri yang lebih matang dan membumi… itu layak dicoba. Dan dipilihlah Vaughn Bennett, yang seratus persen biasa-biasa saja dan sedang memutar otak mencari uang untuk membantu menghidupi keluarga. Selain bayaran untuk menjadi pacar bohongan sang superstar, ia juga mendapat kesempatan mencicipi glamornya Hollywood. Gadis mana yang tidak suka? Namun saat batas-batas antara ilusi dan realitas mengabur, sandiwara setengah hati itu menjebak Oak dan Vaughn dalam cinta yang perlahan bersemi…'
            ]);
        DB::table('details')->insert([
            'books_id' => 5,
            'author' => 'Vicki Cobb',
            'publisher' => 'Gagas Media',
            'year' => '2018',
            'description' => 'With revised and updated material, a brand-new look, and hours of innovative, educational experiments, this science classic by award-winning author Vicki Cobb will be devoured by a whole new generation of readers! Kids take the reins in the kitchen with this hands-on book of edible science experiments! With contemporary information that reflects changes in the world of processing and preserving foods, this cookbook demonstrates the scientific principles that underpin the chemical reactions we witness every day just by cooking. And once readers have tested their theories and completed their experiments, they can feast on the results! From salad dressing to mayonnaise, celery to popcorn, and muffins to meringues, this book uses food to make science accessible to a range of tastes. Also included is essential information on eating healthfully, plus additional resources for further exploration.'
        ]);
        DB::table('details')->insert([
            'books_id' => 6,
            'author' => 'Amir Aczel',
            'publisher' => 'Gagas Media',
            'year' => '2018',
            'description' => ' The renowned science writer, mathematician, and bestselling author of masterfully refutes the overreaching claims of the New Atheists, providing millions of educated believers with a clear, engaging explanation of what science really says, how theres still much space for the Divine in the universe, and why faith in both God and empirical science are not mutually exclusive In recent years a highly publicized coterie of scientists and thinkers, including Richard Dawkins, the late Christopher Hitchens, and Lawrence Krauss, have vehemently contended that breakthroughs in modern science have disproven the existence of God, asserting we must accept that the creation of the universe came out of nothing, that religion is evil, that evolution fully explains the dazzling complexity of life, and more. However, in this much-needed book, veteran science journalist Amir Aczel profoundly disagrees and convincingly demonstrates that science has not, as yet, provided any definitive proof refuting the existence of God. Based on interviews with eleven Nobel Prize winners and many other prominent physicists, biologists, anthropologists, and psychologists, as well as leading theologians and spiritual leaders, is a fascinating tour through the history of science and a brilliant and incisive analysis of the religious implications of our ever-increasing understanding of life and the universe. Throughout, Aczel reminds us that science, at its best, is about the dispassionate pursuit of truth not a weapon in cultural debates. Respectful of both science and faith and argued from the perspective of no single religious tradition Aczels book is an essential corrective that should be read by all.'
        ]);
        DB::table('details')->insert([
            'books_id' => 7,
            'author' => 'Timothy Ferris',
            'publisher' => 'Gramedia Pustaka Utama (GPU)',
            'year' => '2020',
            'description' => 'In his most important book to date, award-winning author Timothy Ferris‚Äîthe best popular science writer in the English language today ()‚Äîmakes a passionate case for science as the inspiration behind the rise of liberalism and democracy. Ferris argues that just as the scientific revolution rescued billions from poverty, fear, hunger, and disease, the Enlight-enment values it inspired has swelled the number of persons living in free and democratic societies from less than 1 percent of the world population four centuries ago to more than a third today.
Ferris deftly investigates the evolution of these scientific and political revolutions, demonstrating that they are inextricably bound. He shows how science was integral to the American Revolution but misinterpreted in the French Revolution; reflects on the history of liberalism, stressing its widely underestimated and mutually beneficial relationship with science; and surveys the forces that have opposed science and liberalism‚Äîfrom communism and fascism to postmodernism and Islamic fundamentalism.
A sweeping intellectual history, is a stunningly original work that transcends the antiquated concepts of left and right.'
        ]);
        DB::table('details')->insert([
            'books_id' => 8,
            'author' => 'Bruce M. Hood',
            'publisher' => 'Gagas Media',
            'year' => '2021',
            'description' => 'In , cognitive psychologist Bruce Hood examines the ways in which humans understand the supernatural, revealing what makes us believe in the unbelievable.
*Previously published as .'
        ]);
        DB::table('details')->insert([
            'books_id' => 9,
            'author' => 'Rully Charitas IP',
            'publisher' => 'Gramedia Pustaka Utama (GPU)',
            'year' => '2018',
            'description' => 'Buku ini menggunakan istilah ‘kencan’ pada setiap bab nya. Ini dikarenakan, untuk mengenal lebih jauh tentang komputer, Anda harus dapat ‘berkencan’ dengan mereka. Berikut ‘perkencanan’ di setiap bagian dalam buku ini, Kencan pertama buku ini, menceritakan sejarah komputer, pengertian komputer, penggolongan komputer, generasi komputer, dan beberapa hal yang mencakup tentang komputer secara global. Kencan kedua buku ini, membahas tentang bagian-bagian komputer. Seperti, casing, motherboard, harddisk, dan lain sebagainya. Pada bagian ini, saya memberikan banyak sekali gambar-gambar dari masing-masing bagian komputer. Sehingga, Anda dapat membayangkan bentuk bagian komputer yang sesungguhnya. Kencan ketiga buku ini, membahas tentang beberapa aplikasi hardware lain yang menunjang komputer Anda. Seperti, USB, printer, modem dan lain sebagainya dan kencan keempat berisi tentang bagaimana komputer itu bekerja. Disamping itu, setiap bagian pada buku ini, diberikan penjelasan yang mudah dipahami oleh para pembaca, berikut gambar-gambar dari setiap hal yang dijelaskan, sehingga para pembaca dapat membayangkan bentuk hardware dari komputer tersebut seperti yang sebenarnya.'       ]);
        DB::table('details')->insert([
            'books_id' => 10,
            'author' => 'Jogiyanto Hartono, Akt., MBA, Ph.D',
            'publisher' => 'Elexmedia Komputindo',
            'year' => '2019',
            'description' => 'Program Komputer Untuk Analisa Ekonomi'        ]);

    }
}
